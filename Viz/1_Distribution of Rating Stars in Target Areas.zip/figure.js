var figure = {
    "frames": [], 
    "layout": {
        "title": "Distribution of Rating Stars in Target Areas", 
        "paper_bgcolor": "#F5F6F9", 
        "plot_bgcolor": "#F5F6F9", 
        "xaxis1": {
            "tickfont": {
                "color": "#4D5663"
            }, 
            "title": "Rating Star", 
            "showgrid": true, 
            "zerolinecolor": "#E1E5ED", 
            "titlefont": {
                "color": "#4D5663"
            }, 
            "gridcolor": "#E1E5ED"
        }, 
        "yaxis1": {
            "tickfont": {
                "color": "#4D5663"
            }, 
            "title": "The Number of Restaurants", 
            "showgrid": true, 
            "zerolinecolor": "#E1E5ED", 
            "titlefont": {
                "color": "#4D5663"
            }, 
            "gridcolor": "#E1E5ED"
        }, 
        "titlefont": {
            "color": "#4D5663"
        }, 
        "legend": {
            "bgcolor": "#F5F6F9", 
            "font": {
                "color": "#4D5663"
            }
        }
    }, 
    "data": [
        {
            "name": "The Greater Torronto Area", 
            "text": "", 
            "xsrc": "proidea:14:71afe3", 
            "mode": "lines", 
            "ysrc": "proidea:14:534beb", 
            "y": [
                26, 
                72, 
                218, 
                512, 
                1281, 
                1849, 
                1733, 
                632, 
                141
            ], 
            "x": [
                1.0, 
                1.5, 
                2.0, 
                2.5, 
                3.0, 
                3.5, 
                4.0, 
                4.5, 
                5.0
            ], 
            "line": {
                "dash": "solid", 
                "color": "rgba(255, 153, 51, 1.0)", 
                "width": 1.3
            }, 
            "fill": "tonexty", 
            "type": "scatter", 
            "fillcolor": "rgba(255, 153, 51, 0.3)"
        }, 
        {
            "name": "The Greater Phoenix Area", 
            "text": "", 
            "xsrc": "proidea:14:71afe3", 
            "mode": "lines", 
            "ysrc": "proidea:14:445bee", 
            "y": [
                42, 
                142, 
                419, 
                957, 
                2077, 
                3223, 
                3292, 
                1314, 
                272
            ], 
            "x": [
                1.0, 
                1.5, 
                2.0, 
                2.5, 
                3.0, 
                3.5, 
                4.0, 
                4.5, 
                5.0
            ], 
            "line": {
                "dash": "solid", 
                "color": "rgba(55, 128, 191, 1.0)", 
                "width": 1.3
            }, 
            "fill": "tonexty", 
            "type": "scatter", 
            "fillcolor": "rgba(55, 128, 191, 0.3)"
        }, 
        {
            "name": "The Greater Las Vegas Area", 
            "text": "", 
            "xsrc": "proidea:14:71afe3", 
            "mode": "lines", 
            "ysrc": "proidea:14:e7855c", 
            "y": [
                48, 
                180, 
                565, 
                1249, 
                2656, 
                4109, 
                4292, 
                1835, 
                368
            ], 
            "x": [
                1.0, 
                1.5, 
                2.0, 
                2.5, 
                3.0, 
                3.5, 
                4.0, 
                4.5, 
                5.0
            ], 
            "line": {
                "dash": "solid", 
                "color": "rgba(50, 171, 96, 1.0)", 
                "width": 1.3
            }, 
            "fill": "tonexty", 
            "type": "scatter", 
            "fillcolor": "rgba(50, 171, 96, 0.3)"
        }
    ]
}