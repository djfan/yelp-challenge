var figure = {
    "frames": [], 
    "layout": {
        "barmode": "stack", 
        "paper_bgcolor": "#FFFFFF", 
        "plot_bgcolor": "#E5E5E5", 
        "title": "Distribution of Chinese and Japanese Cuisine Types in Target Areas", 
        "xaxis1": {
            "tickfont": {
                "color": "#666666"
            }, 
            "title": "The Number of Restaurants", 
            "showgrid": true, 
            "zerolinecolor": "#F6F6F6", 
            "titlefont": {
                "color": "#666666"
            }, 
            "gridcolor": "#F6F6F6"
        }, 
        "yaxis1": {
            "tickfont": {
                "color": "#666666"
            }, 
            "title": "The Greater City Area", 
            "showgrid": true, 
            "zerolinecolor": "#F6F6F6", 
            "titlefont": {
                "color": "#666666"
            }, 
            "gridcolor": "#F6F6F6"
        }, 
        "bargap": 0.1, 
        "titlefont": {
            "color": "#151516"
        }, 
        "legend": {
            "bgcolor": "#FFFFFF", 
            "font": {
                "color": "#666666"
            }, 
            "traceorder": "normal"
        }
    }, 
    "data": [
        {
            "name": "Others", 
            "ysrc": "proidea:27:a8e5fb", 
            "xsrc": "proidea:27:4d0f05", 
            "marker": {
                "color": "rgba(226, 74, 51, 0.6)", 
                "line": {
                    "color": "rgba(226, 74, 51, 1.0)", 
                    "width": 1
                }
            }, 
            "text": "", 
            "y": [
                "Las Vegas", 
                "Phoenix", 
                "Torronto"
            ], 
            "x": [
                2899, 
                4546, 
                5060
            ], 
            "type": "bar", 
            "orientation": "h"
        }, 
        {
            "name": "Chinese Cuisine", 
            "ysrc": "proidea:27:a8e5fb", 
            "xsrc": "proidea:27:912bf9", 
            "marker": {
                "color": "rgba(62, 111, 176, 0.6)", 
                "line": {
                    "color": "rgba(62, 111, 176, 1.0)", 
                    "width": 1
                }
            }, 
            "text": "", 
            "y": [
                "Las Vegas", 
                "Phoenix", 
                "Torronto"
            ], 
            "x": [
                410, 
                482, 
                853
            ], 
            "type": "bar", 
            "orientation": "h"
        }, 
        {
            "name": "Japanese Cuisine", 
            "ysrc": "proidea:27:a8e5fb", 
            "xsrc": "proidea:27:b5d336", 
            "marker": {
                "color": "rgba(132, 118, 202, 0.6)", 
                "line": {
                    "color": "rgba(132, 118, 202, 1.0)", 
                    "width": 1
                }
            }, 
            "text": "", 
            "y": [
                "Las Vegas", 
                "Phoenix", 
                "Torronto"
            ], 
            "x": [
                255, 
                246, 
                551
            ], 
            "type": "bar", 
            "orientation": "h"
        }
    ]
}